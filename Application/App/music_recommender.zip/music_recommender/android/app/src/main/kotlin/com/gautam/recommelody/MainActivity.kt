package com.gautam.recommelody

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
